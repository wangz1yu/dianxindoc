<?php

return [
    'APP_VERSION' => '5.2.0',
];
