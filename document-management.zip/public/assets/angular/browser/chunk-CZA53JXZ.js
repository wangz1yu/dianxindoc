var t=class{constructor(){this.totalCount=0,this.pageSize=0,this.skip=0,this.totalPages=0}};export{t as a};
